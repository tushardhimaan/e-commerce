package com.zosh.request;

public class DeleteProductRequest {
	
//	private Long 

}
